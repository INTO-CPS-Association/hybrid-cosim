
// define class name and unique id
#define MODEL_IDENTIFIER Window
#define MODEL_GUID "{bead1740-5500-42db-88d5-eb3872b63305}"

// include fmu header files, typedefs and macros
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "openmodelica.h"
#include "openmodelica_func.h"
#include "simulation_data.h"
#include "util/omc_error.h"
#include "Window_functions.h"
#include "simulation/solver/initialization/initialization.h"
#include "simulation/solver/events.h"
#include "fmu2_model_interface.h"

#ifdef __cplusplus
extern "C" {
#endif

void setStartValues(ModelInstance *comp);
void setDefaultStartValues(ModelInstance *comp);
void eventUpdate(ModelInstance* comp, fmi2EventInfo* eventInfo);
fmi2Real getReal(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setReal(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Real value);
fmi2Integer getInteger(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setInteger(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Integer value);
fmi2Boolean getBoolean(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setBoolean(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Boolean value);
fmi2String getString(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setString(ModelInstance* comp, const fmi2ValueReference vr, fmi2String value);
fmi2Status setExternalFunction(ModelInstance* c, const fmi2ValueReference vr, const void* value);

// define model size
#define NUMBER_OF_STATES 0
#define NUMBER_OF_EVENT_INDICATORS 0
#define NUMBER_OF_REALS 9
#define NUMBER_OF_INTEGERS 0
#define NUMBER_OF_STRINGS 0
#define NUMBER_OF_BOOLEANS 0
#define NUMBER_OF_EXTERNALFUNCTIONS 0

// define variable data for model
#define $Pfriction_vr 0 
#define $Pobj_F_vr 1 
#define $Pomega_input_vr 2 
#define $Ptau_vr 3 
#define $Ptheta_input_vr 4 
#define $Pv_vr 5 
#define $Px_vr 6 
#define $Pb_vr 7 
#define $Pr_vr 8 


// define initial state vector as vector of value references
#define STATES {  }
#define STATESDERIVATIVES {  }


// implementation of the Model Exchange functions
  extern void Window_setupDataStruc(DATA *data);
  #define fmu2_model_interface_setupDataStruc Window_setupDataStruc
  #include "fmu2_model_interface.c"

// Set values for all variables that define a start value
void setDefaultStartValues(ModelInstance *comp) {

comp->fmuData->modelData->realVarsData[0].attribute.start = 0;
comp->fmuData->modelData->realVarsData[1].attribute.start = 0;
comp->fmuData->modelData->realVarsData[2].attribute.start = 0;
comp->fmuData->modelData->realVarsData[3].attribute.start = 0;
comp->fmuData->modelData->realVarsData[4].attribute.start = 0;
comp->fmuData->modelData->realVarsData[5].attribute.start = 0;
comp->fmuData->modelData->realVarsData[6].attribute.start = 0;
comp->fmuData->modelData->realParameterData[0].attribute.start = 10.0;
comp->fmuData->modelData->realParameterData[1].attribute.start = 0.11;
}
// Set values for all variables that define a start value
void setStartValues(ModelInstance *comp) {

  comp->fmuData->modelData->realVarsData[0].attribute.start =  comp->fmuData->localData[0]->realVars[0];
  comp->fmuData->modelData->realVarsData[1].attribute.start =  comp->fmuData->localData[0]->realVars[1];
  comp->fmuData->modelData->realVarsData[2].attribute.start =  comp->fmuData->localData[0]->realVars[2];
  comp->fmuData->modelData->realVarsData[3].attribute.start =  comp->fmuData->localData[0]->realVars[3];
  comp->fmuData->modelData->realVarsData[4].attribute.start =  comp->fmuData->localData[0]->realVars[4];
  comp->fmuData->modelData->realVarsData[5].attribute.start =  comp->fmuData->localData[0]->realVars[5];
  comp->fmuData->modelData->realVarsData[6].attribute.start =  comp->fmuData->localData[0]->realVars[6];
comp->fmuData->modelData->realParameterData[0].attribute.start = comp->fmuData->simulationInfo->realParameter[0];
comp->fmuData->modelData->realParameterData[1].attribute.start = comp->fmuData->simulationInfo->realParameter[1];
}
  // Used to set the next time event, if any.
  void eventUpdate(ModelInstance* comp, fmi2EventInfo* eventInfo) {
  }
  
  fmi2Real getReal(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        case $Pfriction_vr : return comp->fmuData->localData[0]->realVars[0]; break;
        case $Pobj_F_vr : return comp->fmuData->localData[0]->realVars[1]; break;
        case $Pomega_input_vr : return comp->fmuData->localData[0]->realVars[2]; break;
        case $Ptau_vr : return comp->fmuData->localData[0]->realVars[3]; break;
        case $Ptheta_input_vr : return comp->fmuData->localData[0]->realVars[4]; break;
        case $Pv_vr : return comp->fmuData->localData[0]->realVars[5]; break;
        case $Px_vr : return comp->fmuData->localData[0]->realVars[6]; break;
        case $Pb_vr : return comp->fmuData->simulationInfo->realParameter[0]; break;
        case $Pr_vr : return comp->fmuData->simulationInfo->realParameter[1]; break;
        default:
            return 0;
    }
  }
  
  fmi2Status setReal(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Real value) {
    switch (vr) {
        case $Pfriction_vr : comp->fmuData->localData[0]->realVars[0] = value; break;
        case $Pobj_F_vr : comp->fmuData->localData[0]->realVars[1] = value; break;
        case $Pomega_input_vr : comp->fmuData->localData[0]->realVars[2] = value; break;
        case $Ptau_vr : comp->fmuData->localData[0]->realVars[3] = value; break;
        case $Ptheta_input_vr : comp->fmuData->localData[0]->realVars[4] = value; break;
        case $Pv_vr : comp->fmuData->localData[0]->realVars[5] = value; break;
        case $Px_vr : comp->fmuData->localData[0]->realVars[6] = value; break;
        case $Pb_vr : comp->fmuData->simulationInfo->realParameter[0] = value; break;
        case $Pr_vr : comp->fmuData->simulationInfo->realParameter[1] = value; break;
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  
  fmi2Integer getInteger(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        default:
            return 0;
    }
  }
  fmi2Status setInteger(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Integer value) {
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  fmi2Boolean getBoolean(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        default:
            return fmi2False;
    }
  }
  
  fmi2Status setBoolean(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Boolean value) {
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  
  fmi2String getString(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        default:
            return "";
    }
  }
  
  fmi2Status setString(ModelInstance* comp, const fmi2ValueReference vr, fmi2String value) {
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  
  fmi2Status setExternalFunction(ModelInstance* c, const fmi2ValueReference vr, const void* value){
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  

#ifdef __cplusplus
}
#endif

