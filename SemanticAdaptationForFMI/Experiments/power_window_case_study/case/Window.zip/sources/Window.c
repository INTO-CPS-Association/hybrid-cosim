/* Main Simulation File */
#include "Window_model.h"


/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int Window_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->localData[0]->realVars[1] /* obj_F variable */ = data->simulationInfo->inputVars[0];
  data->localData[0]->realVars[2] /* omega_input variable */ = data->simulationInfo->inputVars[1];
  data->localData[0]->realVars[4] /* theta_input variable */ = data->simulationInfo->inputVars[2];
  
  TRACE_POP
  return 0;
}

int Window_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->inputVars[0] = data->modelData->realVarsData[1].attribute.start;
  data->simulationInfo->inputVars[1] = data->modelData->realVarsData[2].attribute.start;
  data->simulationInfo->inputVars[2] = data->modelData->realVarsData[4].attribute.start;
  
  TRACE_POP
  return 0;
}

int Window_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->modelData->realVarsData[1].attribute.start = data->simulationInfo->inputVars[0];
  data->modelData->realVarsData[2].attribute.start = data->simulationInfo->inputVars[1];
  data->modelData->realVarsData[4].attribute.start = data->simulationInfo->inputVars[2];
  
  TRACE_POP
  return 0;
}

int Window_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  names[0] = (char *) data->modelData->realVarsData[1].info.name;
  names[1] = (char *) data->modelData->realVarsData[2].info.name;
  names[2] = (char *) data->modelData->realVarsData[4].info.name;
  
  TRACE_POP
  return 0;
}

int Window_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->outputVars[0] = data->localData[0]->realVars[0] /* friction variable */;
  data->simulationInfo->outputVars[1] = data->localData[0]->realVars[3] /* tau variable */;
  data->simulationInfo->outputVars[2] = data->localData[0]->realVars[5] /* v variable */;
  data->simulationInfo->outputVars[3] = data->localData[0]->realVars[6] /* x variable */;
  
  TRACE_POP
  return 0;
}


/*
 equation index: 5
 type: SIMPLE_ASSIGN
 x = r * theta_input
 */
void Window_eqFunction_5(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,5};
  data->localData[0]->realVars[6] /* x variable */ = (data->simulationInfo->realParameter[1] /* r PARAM */) * (data->localData[0]->realVars[4] /* theta_input variable */);
  TRACE_POP
}
/*
 equation index: 6
 type: SIMPLE_ASSIGN
 v = r * omega_input
 */
void Window_eqFunction_6(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,6};
  data->localData[0]->realVars[5] /* v variable */ = (data->simulationInfo->realParameter[1] /* r PARAM */) * (data->localData[0]->realVars[2] /* omega_input variable */);
  TRACE_POP
}
/*
 equation index: 7
 type: SIMPLE_ASSIGN
 friction = b * v
 */
void Window_eqFunction_7(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,7};
  data->localData[0]->realVars[0] /* friction variable */ = (data->simulationInfo->realParameter[0] /* b PARAM */) * (data->localData[0]->realVars[5] /* v variable */);
  TRACE_POP
}
/*
 equation index: 8
 type: SIMPLE_ASSIGN
 tau = obj_F * r + friction
 */
void Window_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  data->localData[0]->realVars[3] /* tau variable */ = (data->localData[0]->realVars[1] /* obj_F variable */) * (data->simulationInfo->realParameter[1] /* r PARAM */) + data->localData[0]->realVars[0] /* friction variable */;
  TRACE_POP
}


int Window_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  Window_functionLocalKnownVars(data, threadData);
  Window_eqFunction_5(data, threadData);

  Window_eqFunction_6(data, threadData);

  Window_eqFunction_7(data, threadData);

  Window_eqFunction_8(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Window_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Window_symEulerUpdate(DATA *data, modelica_real dt)
{
  return -1;
}



int Window_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  Window_functionLocalKnownVars(data, threadData);
  /* no ODE systems */

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "Window_12jac.h"
#include "Window_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks Window_callback = {
   NULL,
   NULL,
   NULL,
   Window_callExternalObjectConstructors,
   Window_callExternalObjectDestructors,
   NULL,
   NULL,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   Window_initializeStateSets,
   #else
   NULL,
   #endif
   Window_initializeDAEmodeData,
   Window_functionODE,
   Window_functionAlgebraics,
   Window_functionDAE,
   Window_functionLocalKnownVars,
   Window_input_function,
   Window_input_function_init,
   Window_input_function_updateStartValues,
   Window_output_function,
   Window_function_storeDelayed,
   Window_updateBoundVariableAttributes,
   0 /* useHomotopy */,
   Window_functionInitialEquations,
   Window_functionInitialEquations_lambda0,
   Window_functionRemovedInitialEquations,
   Window_updateBoundParameters,
   Window_checkForAsserts,
   Window_function_ZeroCrossingsEquations,
   Window_function_ZeroCrossings,
   Window_function_updateRelations,
   Window_checkForDiscreteChanges,
   Window_zeroCrossingDescription,
   Window_relationDescription,
   Window_function_initSample,
   Window_INDEX_JAC_A,
   Window_INDEX_JAC_B,
   Window_INDEX_JAC_C,
   Window_INDEX_JAC_D,
   Window_initialAnalyticJacobianA,
   Window_initialAnalyticJacobianB,
   Window_initialAnalyticJacobianC,
   Window_initialAnalyticJacobianD,
   Window_functionJacA_column,
   Window_functionJacB_column,
   Window_functionJacC_column,
   Window_functionJacD_column,
   Window_linear_model_frame,
   Window_linear_model_datarecovery_frame,
   Window_mayer,
   Window_lagrange,
   Window_pickUpBoundsForInputsInOptimization,
   Window_setInputData,
   Window_getTimeGrid,
   Window_symEulerUpdate,
   Window_function_initSynchronous,
   Window_function_updateSynchronous,
   Window_function_equationsSynchronous,
   Window_read_input_fmu
   #ifdef FMU_EXPERIMENTAL
   ,Window_functionODE_Partial
   ,Window_functionFMIJacobian
   #endif
   ,Window_inputNames


};

void Window_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &Window_callback;
  data->modelData->modelName = "Window";
  data->modelData->modelFilePrefix = "Window";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/Joachim/Documents/Research/HybridCosimulation/ModelicaModels";
  data->modelData->modelGUID = "{bead1740-5500-42db-88d5-eb3872b63305}";
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData =
  #if defined(OMC_MINIMAL_METADATA)
    NULL;
  #else
  #include "Window_info.c"
  #endif
  ;
  
  data->modelData->nStates = 0;
  data->modelData->nVariablesReal = 7;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 2;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 3;
  data->modelData->nOutputVars = 4;
  
  data->modelData->nAliasReal = 0;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 0;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 0;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "Window_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 9;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 4;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

