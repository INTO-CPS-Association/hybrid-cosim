/* Linearization */
#include "Window_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *Window_linear_model_frame()
{
  return "model linear_Window\n  parameter Integer n = 0; // states\n  parameter Integer k = 3; // top-level inputs\n  parameter Integer l = 4; // top-level outputs\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[3] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,3] = zeros(0,3);%s\n"
  "  parameter Real C[4,0] = zeros(4,0);%s\n"
  "  parameter Real D[4,3] = [%s];\n"
  "  Real x[0];\n"
  "  input Real u[3](start= u0);\n"
  "  output Real y[4];\n"
  "\n    Real 'u_obj_F' = u[1];\n  Real 'u_omega_input' = u[2];\n  Real 'u_theta_input' = u[3];\n  Real 'y_friction' = y[1];\n  Real 'y_tau' = y[2];\n  Real 'y_v' = y[3];\n  Real 'y_x' = y[4];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linear_Window;\n";
}
const char *Window_linear_model_datarecovery_frame()
{
  return "model linear_Window\n  parameter Integer n = 0; // states\n  parameter Integer k = 3; // top-level inputs\n  parameter Integer l = 4; // top-level outputs\n  parameter Integer nz = 7; // data recovery variables\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[3] = {%s};\n"
  "  parameter Real z0[7] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,3] = zeros(0,3);%s\n"
  "  parameter Real C[4,0] = zeros(4,0);%s\n"
  "  parameter Real D[4,3] = [%s];\n"
  "  parameter Real Cz[7,0] = zeros(7,0);%s\n"
  "  parameter Real Dz[7,3] = [%s];\n"
  "  Real x[0];\n"
  "  input Real u[3](start= u0);\n"
  "  output Real y[4];\n"
  "  output Real z[7];\n"
  "\n  Real 'u_obj_F' = u[1];\n  Real 'u_omega_input' = u[2];\n  Real 'u_theta_input' = u[3];\n  Real 'y_friction' = y[1];\n  Real 'y_tau' = y[2];\n  Real 'y_v' = y[3];\n  Real 'y_x' = y[4];\n  Real 'z_friction' = z[1];\n  Real 'z_obj_F' = z[2];\n  Real 'z_omega_input' = z[3];\n  Real 'z_tau' = z[4];\n  Real 'z_theta_input' = z[5];\n  Real 'z_v' = z[6];\n  Real 'z_x' = z[7];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linear_Window;\n";
}
#if defined(__cplusplus)
}
#endif

