/* Initialization */
#include "Window_model.h"
#include "Window_11mix.h"
#include "Window_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif

void Window_functionInitialEquations_0(DATA *data, threadData_t *threadData);


/*
 equation index: 1
 type: SIMPLE_ASSIGN
 x = r * theta_input
 */
void Window_eqFunction_1(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,1};
  data->localData[0]->realVars[6] /* x variable */ = (data->simulationInfo->realParameter[1] /* r PARAM */) * (data->localData[0]->realVars[4] /* theta_input variable */);
  TRACE_POP
}

/*
 equation index: 2
 type: SIMPLE_ASSIGN
 v = r * omega_input
 */
void Window_eqFunction_2(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,2};
  data->localData[0]->realVars[5] /* v variable */ = (data->simulationInfo->realParameter[1] /* r PARAM */) * (data->localData[0]->realVars[2] /* omega_input variable */);
  TRACE_POP
}

/*
 equation index: 3
 type: SIMPLE_ASSIGN
 friction = b * v
 */
void Window_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  data->localData[0]->realVars[0] /* friction variable */ = (data->simulationInfo->realParameter[0] /* b PARAM */) * (data->localData[0]->realVars[5] /* v variable */);
  TRACE_POP
}

/*
 equation index: 4
 type: SIMPLE_ASSIGN
 tau = obj_F * r + friction
 */
void Window_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  data->localData[0]->realVars[3] /* tau variable */ = (data->localData[0]->realVars[1] /* obj_F variable */) * (data->simulationInfo->realParameter[1] /* r PARAM */) + data->localData[0]->realVars[0] /* friction variable */;
  TRACE_POP
}
void Window_functionInitialEquations_0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  Window_eqFunction_1(data, threadData);
  Window_eqFunction_2(data, threadData);
  Window_eqFunction_3(data, threadData);
  Window_eqFunction_4(data, threadData);
  TRACE_POP
}


int Window_functionInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  Window_functionInitialEquations_0(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Window_functionInitialEquations_lambda0(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->discreteCall = 1;
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}
int Window_functionRemovedInitialEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int *equationIndexes = NULL;
  double res = 0.0;

  
  TRACE_POP
  return 0;
}


#if defined(__cplusplus)
}
#endif

