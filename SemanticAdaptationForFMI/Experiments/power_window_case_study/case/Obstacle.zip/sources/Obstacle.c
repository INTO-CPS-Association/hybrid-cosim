/* Main Simulation File */
#include "Obstacle_model.h"


/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int Obstacle_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->localData[0]->realVars[2] /* x variable */ = data->simulationInfo->inputVars[0];
  
  TRACE_POP
  return 0;
}

int Obstacle_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->inputVars[0] = data->modelData->realVarsData[2].attribute.start;
  
  TRACE_POP
  return 0;
}

int Obstacle_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->modelData->realVarsData[2].attribute.start = data->simulationInfo->inputVars[0];
  
  TRACE_POP
  return 0;
}

int Obstacle_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  names[0] = (char *) data->modelData->realVarsData[2].info.name;
  
  TRACE_POP
  return 0;
}

int Obstacle_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->outputVars[0] = data->localData[0]->realVars[0] /* F variable */;
  
  TRACE_POP
  return 0;
}


/*
 equation index: 3
 type: SIMPLE_ASSIGN
 compression = x - fixed_x
 */
void Obstacle_eqFunction_3(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,3};
  data->localData[0]->realVars[1] /* compression variable */ = data->localData[0]->realVars[2] /* x variable */ - data->simulationInfo->realParameter[1] /* fixed_x PARAM */;
  TRACE_POP
}
/*
 equation index: 4
 type: SIMPLE_ASSIGN
 F = if x > fixed_x then c * compression else 0.0
 */
void Obstacle_eqFunction_4(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,4};
  modelica_boolean tmp1;
  RELATIONHYSTERESIS(tmp1, data->localData[0]->realVars[2] /* x variable */, data->simulationInfo->realParameter[1] /* fixed_x PARAM */, 0, Greater);
  data->localData[0]->realVars[0] /* F variable */ = (tmp1?(data->simulationInfo->realParameter[0] /* c PARAM */) * (data->localData[0]->realVars[1] /* compression variable */):0.0);
  TRACE_POP
}


int Obstacle_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  Obstacle_functionLocalKnownVars(data, threadData);
  Obstacle_eqFunction_3(data, threadData);

  Obstacle_eqFunction_4(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int Obstacle_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int Obstacle_symEulerUpdate(DATA *data, modelica_real dt)
{
  return -1;
}



int Obstacle_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  Obstacle_functionLocalKnownVars(data, threadData);
  /* no ODE systems */

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "Obstacle_12jac.h"
#include "Obstacle_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks Obstacle_callback = {
   NULL,
   NULL,
   NULL,
   Obstacle_callExternalObjectConstructors,
   Obstacle_callExternalObjectDestructors,
   NULL,
   NULL,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   Obstacle_initializeStateSets,
   #else
   NULL,
   #endif
   Obstacle_initializeDAEmodeData,
   Obstacle_functionODE,
   Obstacle_functionAlgebraics,
   Obstacle_functionDAE,
   Obstacle_functionLocalKnownVars,
   Obstacle_input_function,
   Obstacle_input_function_init,
   Obstacle_input_function_updateStartValues,
   Obstacle_output_function,
   Obstacle_function_storeDelayed,
   Obstacle_updateBoundVariableAttributes,
   0 /* useHomotopy */,
   Obstacle_functionInitialEquations,
   Obstacle_functionInitialEquations_lambda0,
   Obstacle_functionRemovedInitialEquations,
   Obstacle_updateBoundParameters,
   Obstacle_checkForAsserts,
   Obstacle_function_ZeroCrossingsEquations,
   Obstacle_function_ZeroCrossings,
   Obstacle_function_updateRelations,
   Obstacle_checkForDiscreteChanges,
   Obstacle_zeroCrossingDescription,
   Obstacle_relationDescription,
   Obstacle_function_initSample,
   Obstacle_INDEX_JAC_A,
   Obstacle_INDEX_JAC_B,
   Obstacle_INDEX_JAC_C,
   Obstacle_INDEX_JAC_D,
   Obstacle_initialAnalyticJacobianA,
   Obstacle_initialAnalyticJacobianB,
   Obstacle_initialAnalyticJacobianC,
   Obstacle_initialAnalyticJacobianD,
   Obstacle_functionJacA_column,
   Obstacle_functionJacB_column,
   Obstacle_functionJacC_column,
   Obstacle_functionJacD_column,
   Obstacle_linear_model_frame,
   Obstacle_linear_model_datarecovery_frame,
   Obstacle_mayer,
   Obstacle_lagrange,
   Obstacle_pickUpBoundsForInputsInOptimization,
   Obstacle_setInputData,
   Obstacle_getTimeGrid,
   Obstacle_symEulerUpdate,
   Obstacle_function_initSynchronous,
   Obstacle_function_updateSynchronous,
   Obstacle_function_equationsSynchronous,
   Obstacle_read_input_fmu
   #ifdef FMU_EXPERIMENTAL
   ,Obstacle_functionODE_Partial
   ,Obstacle_functionFMIJacobian
   #endif
   ,Obstacle_inputNames


};

void Obstacle_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &Obstacle_callback;
  data->modelData->modelName = "Obstacle";
  data->modelData->modelFilePrefix = "Obstacle";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/Joachim/Documents/Research/HybridCosimulation/ModelicaModels";
  data->modelData->modelGUID = "{8de5bd74-8d30-4a72-9170-0e4bf874b6a8}";
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData =
  #if defined(OMC_MINIMAL_METADATA)
    NULL;
  #else
  #include "Obstacle_info.c"
  #endif
  ;
  
  data->modelData->nStates = 0;
  data->modelData->nVariablesReal = 3;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 2;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 1;
  data->modelData->nOutputVars = 1;
  
  data->modelData->nAliasReal = 0;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 1;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 1;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "Obstacle_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 5;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 4;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

