/* DAE residuals is empty */
 #include "Obstacle_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int Obstacle_initializeDAEmodeData(DATA *inData, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
