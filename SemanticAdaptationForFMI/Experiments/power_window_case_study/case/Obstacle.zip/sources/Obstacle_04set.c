/* Initial State Set */
#include "Obstacle_model.h"
#include "Obstacle_11mix.h"
#include "Obstacle_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void Obstacle_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

