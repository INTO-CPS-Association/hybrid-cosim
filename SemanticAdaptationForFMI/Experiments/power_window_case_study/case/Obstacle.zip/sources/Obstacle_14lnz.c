/* Linearization */
#include "Obstacle_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *Obstacle_linear_model_frame()
{
  return "model linear_Obstacle\n  parameter Integer n = 0; // states\n  parameter Integer k = 1; // top-level inputs\n  parameter Integer l = 1; // top-level outputs\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[1] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,1] = zeros(0,1);%s\n"
  "  parameter Real C[1,0] = zeros(1,0);%s\n"
  "  parameter Real D[1,1] = [%s];\n"
  "  Real x[0];\n"
  "  input Real u[1](start= u0);\n"
  "  output Real y[1];\n"
  "\n    Real 'u_x' = u[1];\n  Real 'y_F' = y[1];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linear_Obstacle;\n";
}
const char *Obstacle_linear_model_datarecovery_frame()
{
  return "model linear_Obstacle\n  parameter Integer n = 0; // states\n  parameter Integer k = 1; // top-level inputs\n  parameter Integer l = 1; // top-level outputs\n  parameter Integer nz = 3; // data recovery variables\n"
  "  parameter Real x0[0] = {%s};\n"
  "  parameter Real u0[1] = {%s};\n"
  "  parameter Real z0[3] = {%s};\n"
  "  parameter Real A[0,0] = zeros(0,0);%s\n"
  "  parameter Real B[0,1] = zeros(0,1);%s\n"
  "  parameter Real C[1,0] = zeros(1,0);%s\n"
  "  parameter Real D[1,1] = [%s];\n"
  "  parameter Real Cz[3,0] = zeros(3,0);%s\n"
  "  parameter Real Dz[3,1] = [%s];\n"
  "  Real x[0];\n"
  "  input Real u[1](start= u0);\n"
  "  output Real y[1];\n"
  "  output Real z[3];\n"
  "\n  Real 'u_x' = u[1];\n  Real 'y_F' = y[1];\n  Real 'z_F' = z[1];\n  Real 'z_compression' = z[2];\n  Real 'z_x' = z[3];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linear_Obstacle;\n";
}
#if defined(__cplusplus)
}
#endif

