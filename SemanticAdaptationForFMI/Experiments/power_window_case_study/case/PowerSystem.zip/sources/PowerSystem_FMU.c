
// define class name and unique id
#define MODEL_IDENTIFIER PowerSystem
#define MODEL_GUID "{c6327117-e5f2-4e48-abcd-318439d1e7c4}"

// include fmu header files, typedefs and macros
#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "openmodelica.h"
#include "openmodelica_func.h"
#include "simulation_data.h"
#include "util/omc_error.h"
#include "PowerSystem_functions.h"
#include "simulation/solver/initialization/initialization.h"
#include "simulation/solver/events.h"
#include "fmu2_model_interface.h"

#ifdef __cplusplus
extern "C" {
#endif

void setStartValues(ModelInstance *comp);
void setDefaultStartValues(ModelInstance *comp);
void eventUpdate(ModelInstance* comp, fmi2EventInfo* eventInfo);
fmi2Real getReal(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setReal(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Real value);
fmi2Integer getInteger(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setInteger(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Integer value);
fmi2Boolean getBoolean(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setBoolean(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Boolean value);
fmi2String getString(ModelInstance* comp, const fmi2ValueReference vr);
fmi2Status setString(ModelInstance* comp, const fmi2ValueReference vr, fmi2String value);
fmi2Status setExternalFunction(ModelInstance* c, const fmi2ValueReference vr, const void* value);

// define model size
#define NUMBER_OF_STATES 3
#define NUMBER_OF_EVENT_INDICATORS 2
#define NUMBER_OF_REALS 16
#define NUMBER_OF_INTEGERS 0
#define NUMBER_OF_STRINGS 0
#define NUMBER_OF_BOOLEANS 0
#define NUMBER_OF_EXTERNALFUNCTIONS 0

// define variable data for model
#define $Pi_vr 0 
#define $Pomega_vr 1 
#define $Ptheta_vr 2 
#define $P$DER$Pi_vr 3 
#define $P$DER$Pomega_vr 4 
#define $P$DER$Ptheta_vr 5 
#define $PV_vr 6 
#define $Pd_vr 7 
#define $Ptau_vr 8 
#define $Pu_vr 9 
#define $PJ_vr 10 
#define $PK_vr 11 
#define $PL_vr 12 
#define $PR_vr 13 
#define $PV_abs_vr 14 
#define $Pb_vr 15 


// define initial state vector as vector of value references
#define STATES { $Pi_vr, $Pomega_vr, $Ptheta_vr }
#define STATESDERIVATIVES { $P$DER$Pi_vr, $P$DER$Pomega_vr, $P$DER$Ptheta_vr }


// implementation of the Model Exchange functions
  extern void PowerSystem_setupDataStruc(DATA *data);
  #define fmu2_model_interface_setupDataStruc PowerSystem_setupDataStruc
  #include "fmu2_model_interface.c"

// Set values for all variables that define a start value
void setDefaultStartValues(ModelInstance *comp) {

comp->fmuData->modelData->realVarsData[0].attribute.start = 0;
comp->fmuData->modelData->realVarsData[1].attribute.start = 0;
comp->fmuData->modelData->realVarsData[2].attribute.start = 0;
comp->fmuData->modelData->realVarsData[3].attribute.start = 0;
comp->fmuData->modelData->realVarsData[4].attribute.start = 0;
comp->fmuData->modelData->realVarsData[5].attribute.start = 0;
comp->fmuData->modelData->realVarsData[6].attribute.start = 0;
comp->fmuData->modelData->realVarsData[7].attribute.start = 0;
comp->fmuData->modelData->realVarsData[8].attribute.start = 0;
comp->fmuData->modelData->realVarsData[9].attribute.start = 0;
comp->fmuData->modelData->realParameterData[0].attribute.start = 0.08500000000000001;
comp->fmuData->modelData->realParameterData[1].attribute.start = 7.45;
comp->fmuData->modelData->realParameterData[2].attribute.start = 0.036;
comp->fmuData->modelData->realParameterData[3].attribute.start = 0.15;
comp->fmuData->modelData->realParameterData[4].attribute.start = 12.0;
comp->fmuData->modelData->realParameterData[5].attribute.start = 5.0;
}
// Set values for all variables that define a start value
void setStartValues(ModelInstance *comp) {

  comp->fmuData->modelData->realVarsData[0].attribute.start =  comp->fmuData->localData[0]->realVars[0];
  comp->fmuData->modelData->realVarsData[1].attribute.start =  comp->fmuData->localData[0]->realVars[1];
  comp->fmuData->modelData->realVarsData[2].attribute.start =  comp->fmuData->localData[0]->realVars[2];
  comp->fmuData->modelData->realVarsData[3].attribute.start =  comp->fmuData->localData[0]->realVars[3];
  comp->fmuData->modelData->realVarsData[4].attribute.start =  comp->fmuData->localData[0]->realVars[4];
  comp->fmuData->modelData->realVarsData[5].attribute.start =  comp->fmuData->localData[0]->realVars[5];
  comp->fmuData->modelData->realVarsData[6].attribute.start =  comp->fmuData->localData[0]->realVars[6];
  comp->fmuData->modelData->realVarsData[7].attribute.start =  comp->fmuData->localData[0]->realVars[7];
  comp->fmuData->modelData->realVarsData[8].attribute.start =  comp->fmuData->localData[0]->realVars[8];
  comp->fmuData->modelData->realVarsData[9].attribute.start =  comp->fmuData->localData[0]->realVars[9];
comp->fmuData->modelData->realParameterData[0].attribute.start = comp->fmuData->simulationInfo->realParameter[0];
comp->fmuData->modelData->realParameterData[1].attribute.start = comp->fmuData->simulationInfo->realParameter[1];
comp->fmuData->modelData->realParameterData[2].attribute.start = comp->fmuData->simulationInfo->realParameter[2];
comp->fmuData->modelData->realParameterData[3].attribute.start = comp->fmuData->simulationInfo->realParameter[3];
comp->fmuData->modelData->realParameterData[4].attribute.start = comp->fmuData->simulationInfo->realParameter[4];
comp->fmuData->modelData->realParameterData[5].attribute.start = comp->fmuData->simulationInfo->realParameter[5];
}
  // Used to set the next time event, if any.
  void eventUpdate(ModelInstance* comp, fmi2EventInfo* eventInfo) {
  }
  
  fmi2Real getReal(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        case $Pi_vr : return comp->fmuData->localData[0]->realVars[0]; break;
        case $Pomega_vr : return comp->fmuData->localData[0]->realVars[1]; break;
        case $Ptheta_vr : return comp->fmuData->localData[0]->realVars[2]; break;
        case $P$DER$Pi_vr : return comp->fmuData->localData[0]->realVars[3]; break;
        case $P$DER$Pomega_vr : return comp->fmuData->localData[0]->realVars[4]; break;
        case $P$DER$Ptheta_vr : return comp->fmuData->localData[0]->realVars[5]; break;
        case $PV_vr : return comp->fmuData->localData[0]->realVars[6]; break;
        case $Pd_vr : return comp->fmuData->localData[0]->realVars[7]; break;
        case $Ptau_vr : return comp->fmuData->localData[0]->realVars[8]; break;
        case $Pu_vr : return comp->fmuData->localData[0]->realVars[9]; break;
        case $PJ_vr : return comp->fmuData->simulationInfo->realParameter[0]; break;
        case $PK_vr : return comp->fmuData->simulationInfo->realParameter[1]; break;
        case $PL_vr : return comp->fmuData->simulationInfo->realParameter[2]; break;
        case $PR_vr : return comp->fmuData->simulationInfo->realParameter[3]; break;
        case $PV_abs_vr : return comp->fmuData->simulationInfo->realParameter[4]; break;
        case $Pb_vr : return comp->fmuData->simulationInfo->realParameter[5]; break;
        default:
            return 0;
    }
  }
  
  fmi2Status setReal(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Real value) {
    switch (vr) {
        case $Pi_vr : comp->fmuData->localData[0]->realVars[0] = value; break;
        case $Pomega_vr : comp->fmuData->localData[0]->realVars[1] = value; break;
        case $Ptheta_vr : comp->fmuData->localData[0]->realVars[2] = value; break;
        case $P$DER$Pi_vr : comp->fmuData->localData[0]->realVars[3] = value; break;
        case $P$DER$Pomega_vr : comp->fmuData->localData[0]->realVars[4] = value; break;
        case $P$DER$Ptheta_vr : comp->fmuData->localData[0]->realVars[5] = value; break;
        case $PV_vr : comp->fmuData->localData[0]->realVars[6] = value; break;
        case $Pd_vr : comp->fmuData->localData[0]->realVars[7] = value; break;
        case $Ptau_vr : comp->fmuData->localData[0]->realVars[8] = value; break;
        case $Pu_vr : comp->fmuData->localData[0]->realVars[9] = value; break;
        case $PJ_vr : comp->fmuData->simulationInfo->realParameter[0] = value; break;
        case $PK_vr : comp->fmuData->simulationInfo->realParameter[1] = value; break;
        case $PL_vr : comp->fmuData->simulationInfo->realParameter[2] = value; break;
        case $PR_vr : comp->fmuData->simulationInfo->realParameter[3] = value; break;
        case $PV_abs_vr : comp->fmuData->simulationInfo->realParameter[4] = value; break;
        case $Pb_vr : comp->fmuData->simulationInfo->realParameter[5] = value; break;
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  
  fmi2Integer getInteger(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        default:
            return 0;
    }
  }
  fmi2Status setInteger(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Integer value) {
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  fmi2Boolean getBoolean(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        default:
            return fmi2False;
    }
  }
  
  fmi2Status setBoolean(ModelInstance* comp, const fmi2ValueReference vr, const fmi2Boolean value) {
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  
  fmi2String getString(ModelInstance* comp, const fmi2ValueReference vr) {
    switch (vr) {
        default:
            return "";
    }
  }
  
  fmi2Status setString(ModelInstance* comp, const fmi2ValueReference vr, fmi2String value) {
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  
  fmi2Status setExternalFunction(ModelInstance* c, const fmi2ValueReference vr, const void* value){
    switch (vr) {
        default:
            return fmi2Error;
    }
    return fmi2OK;
  }
  

#ifdef __cplusplus
}
#endif

