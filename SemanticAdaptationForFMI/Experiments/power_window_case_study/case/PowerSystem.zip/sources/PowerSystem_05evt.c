/* Events: Sample, Zero Crossings, Relations, Discrete Changes */
#include "PowerSystem_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

/* Initializes the raw time events of the simulation using the now
   calcualted parameters. */
void PowerSystem_function_initSample(DATA *data, threadData_t *threadData)
{
  long i=0;
}

const char *PowerSystem_zeroCrossingDescription(int i, int **out_EquationIndexes)
{
  static const char *res[] = {"u > 0.5",
  "d > 0.5"};
  static const int occurEqs0[] = {1,10};
  static const int occurEqs1[] = {1,10};
  static const int *occurEqs[] = {occurEqs0,occurEqs1};
  *out_EquationIndexes = (int*) occurEqs[i];
  return res[i];
}

/* forwarded equations */

int PowerSystem_function_ZeroCrossingsEquations(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->callStatistics.functionZeroCrossingsEquations++;

  
  TRACE_POP
  return 0;
}

int PowerSystem_function_ZeroCrossings(DATA *data, threadData_t *threadData, double *gout)
{
  TRACE_PUSH
  modelica_boolean tmp0;
  modelica_boolean tmp1;
  
  data->simulationInfo->callStatistics.functionZeroCrossings++;
  
  tmp0 = GreaterZC(data->localData[0]->realVars[9] /* u variable */, 0.5, data->simulationInfo->storedRelations[0]);
  gout[0] = (tmp0) ? 1 : -1;
  tmp1 = GreaterZC(data->localData[0]->realVars[7] /* d variable */, 0.5, data->simulationInfo->storedRelations[1]);
  gout[1] = (tmp1) ? 1 : -1;
  
  TRACE_POP
  return 0;
}

const char *PowerSystem_relationDescription(int i)
{
  const char *res[] = {"u > 0.5",
  "d > 0.5"};
  return res[i];
}

int PowerSystem_function_updateRelations(DATA *data, threadData_t *threadData, int evalforZeroCross)
{
  TRACE_PUSH
  modelica_boolean tmp2;
  modelica_boolean tmp3;
  
  if(evalforZeroCross) {
    tmp2 = GreaterZC(data->localData[0]->realVars[9] /* u variable */, 0.5, data->simulationInfo->storedRelations[0]);
    data->simulationInfo->relations[0] = tmp2;
    tmp3 = GreaterZC(data->localData[0]->realVars[7] /* d variable */, 0.5, data->simulationInfo->storedRelations[1]);
    data->simulationInfo->relations[1] = tmp3;
  } else {
    data->simulationInfo->relations[0] = (data->localData[0]->realVars[9] /* u variable */ > 0.5);
    data->simulationInfo->relations[1] = (data->localData[0]->realVars[7] /* d variable */ > 0.5);
  }
  
  TRACE_POP
  return 0;
}

int PowerSystem_checkForDiscreteChanges(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int needToIterate = 0;

  infoStreamPrint(LOG_EVENTS_V, 1, "check for discrete changes at time=%.12g", data->localData[0]->timeValue);
  if (ACTIVE_STREAM(LOG_EVENTS_V)) messageClose(LOG_EVENTS_V);
  
  TRACE_POP
  return needToIterate;
}

#if defined(__cplusplus)
}
#endif

