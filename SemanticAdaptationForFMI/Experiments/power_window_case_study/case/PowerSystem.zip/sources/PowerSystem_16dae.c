/* DAE residuals is empty */
 #include "PowerSystem_model.h"
#ifdef __cplusplus
extern "C" {
#endif
int PowerSystem_initializeDAEmodeData(DATA *inData, DAEMODE_DATA* daeModeData){ return -1; }
#ifdef __cplusplus
}
#endif
