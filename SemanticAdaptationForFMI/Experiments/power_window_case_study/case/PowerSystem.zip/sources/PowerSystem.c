/* Main Simulation File */
#include "PowerSystem_model.h"


/* dummy VARINFO and FILEINFO */
const FILE_INFO dummyFILE_INFO = omc_dummyFileInfo;
const VAR_INFO dummyVAR_INFO = omc_dummyVarInfo;
#if defined(__cplusplus)
extern "C" {
#endif

int PowerSystem_input_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->localData[0]->realVars[7] /* d variable */ = data->simulationInfo->inputVars[0];
  data->localData[0]->realVars[8] /* tau variable */ = data->simulationInfo->inputVars[1];
  data->localData[0]->realVars[9] /* u variable */ = data->simulationInfo->inputVars[2];
  
  TRACE_POP
  return 0;
}

int PowerSystem_input_function_init(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->inputVars[0] = data->modelData->realVarsData[7].attribute.start;
  data->simulationInfo->inputVars[1] = data->modelData->realVarsData[8].attribute.start;
  data->simulationInfo->inputVars[2] = data->modelData->realVarsData[9].attribute.start;
  
  TRACE_POP
  return 0;
}

int PowerSystem_input_function_updateStartValues(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->modelData->realVarsData[7].attribute.start = data->simulationInfo->inputVars[0];
  data->modelData->realVarsData[8].attribute.start = data->simulationInfo->inputVars[1];
  data->modelData->realVarsData[9].attribute.start = data->simulationInfo->inputVars[2];
  
  TRACE_POP
  return 0;
}

int PowerSystem_inputNames(DATA *data, char ** names){
  TRACE_PUSH

  names[0] = (char *) data->modelData->realVarsData[7].info.name;
  names[1] = (char *) data->modelData->realVarsData[8].info.name;
  names[2] = (char *) data->modelData->realVarsData[9].info.name;
  
  TRACE_POP
  return 0;
}

int PowerSystem_output_function(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  data->simulationInfo->outputVars[0] = data->localData[0]->realVars[0] /* i STATE(1) */;
  data->simulationInfo->outputVars[1] = data->localData[0]->realVars[1] /* omega STATE(1) */;
  data->simulationInfo->outputVars[2] = data->localData[0]->realVars[2] /* theta STATE(1,omega) */;
  
  TRACE_POP
  return 0;
}


/*
 equation index: 8
 type: SIMPLE_ASSIGN
 der(theta) = omega
 */
void PowerSystem_eqFunction_8(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,8};
  data->localData[0]->realVars[5] /* der(theta) STATE_DER */ = data->localData[0]->realVars[1] /* omega STATE(1) */;
  TRACE_POP
}
/*
 equation index: 9
 type: SIMPLE_ASSIGN
 der(omega) = DIVISION(K * i - tau - b * omega, J)
 */
void PowerSystem_eqFunction_9(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,9};
  data->localData[0]->realVars[4] /* der(omega) STATE_DER */ = DIVISION_SIM((data->simulationInfo->realParameter[1] /* K PARAM */) * (data->localData[0]->realVars[0] /* i STATE(1) */) - data->localData[0]->realVars[8] /* tau variable */ - ((data->simulationInfo->realParameter[5] /* b PARAM */) * (data->localData[0]->realVars[1] /* omega STATE(1) */)),data->simulationInfo->realParameter[0] /* J PARAM */,"J",equationIndexes);
  TRACE_POP
}
/*
 equation index: 10
 type: SIMPLE_ASSIGN
 V = if u > 0.5 then V_abs else if d > 0.5 then -V_abs else 0.0
 */
void PowerSystem_eqFunction_10(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,10};
  modelica_boolean tmp12;
  modelica_boolean tmp13;
  modelica_boolean tmp14;
  modelica_real tmp15;
  RELATIONHYSTERESIS(tmp12, data->localData[0]->realVars[9] /* u variable */, 0.5, 0, Greater);
  tmp14 = (modelica_boolean)tmp12;
  if(tmp14)
  {
    tmp15 = data->simulationInfo->realParameter[4] /* V_abs PARAM */;
  }
  else
  {
    RELATIONHYSTERESIS(tmp13, data->localData[0]->realVars[7] /* d variable */, 0.5, 1, Greater);
    tmp15 = (tmp13?(-data->simulationInfo->realParameter[4] /* V_abs PARAM */):0.0);
  }
  data->localData[0]->realVars[6] /* V variable */ = tmp15;
  TRACE_POP
}
/*
 equation index: 11
 type: SIMPLE_ASSIGN
 der(i) = DIVISION(V - K * omega - R * i, L)
 */
void PowerSystem_eqFunction_11(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  const int equationIndexes[2] = {1,11};
  data->localData[0]->realVars[3] /* der(i) STATE_DER */ = DIVISION_SIM(data->localData[0]->realVars[6] /* V variable */ - ((data->simulationInfo->realParameter[1] /* K PARAM */) * (data->localData[0]->realVars[1] /* omega STATE(1) */)) - ((data->simulationInfo->realParameter[3] /* R PARAM */) * (data->localData[0]->realVars[0] /* i STATE(1) */)),data->simulationInfo->realParameter[2] /* L PARAM */,"L",equationIndexes);
  TRACE_POP
}


int PowerSystem_functionDAE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH
  int equationIndexes[1] = {0};
  
  data->simulationInfo->needToIterate = 0;
  data->simulationInfo->discreteCall = 1;
  PowerSystem_functionLocalKnownVars(data, threadData);
  PowerSystem_eqFunction_8(data, threadData);

  PowerSystem_eqFunction_9(data, threadData);

  PowerSystem_eqFunction_10(data, threadData);

  PowerSystem_eqFunction_11(data, threadData);
  data->simulationInfo->discreteCall = 0;
  
  TRACE_POP
  return 0;
}


int PowerSystem_functionLocalKnownVars(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  TRACE_POP
  return 0;
}

int PowerSystem_symEulerUpdate(DATA *data, modelica_real dt)
{
  return -1;
}



/* forwarded equations */
extern void PowerSystem_eqFunction_8(DATA* data, threadData_t *threadData);
extern void PowerSystem_eqFunction_9(DATA* data, threadData_t *threadData);
extern void PowerSystem_eqFunction_10(DATA* data, threadData_t *threadData);
extern void PowerSystem_eqFunction_11(DATA* data, threadData_t *threadData);

static void functionODE_system0(DATA *data, threadData_t *threadData)
{
  PowerSystem_eqFunction_8(data, threadData);

  PowerSystem_eqFunction_9(data, threadData);

  PowerSystem_eqFunction_10(data, threadData);

  PowerSystem_eqFunction_11(data, threadData);
}

int PowerSystem_functionODE(DATA *data, threadData_t *threadData)
{
  TRACE_PUSH

  
  data->simulationInfo->callStatistics.functionODE++;
  
  PowerSystem_functionLocalKnownVars(data, threadData);
  functionODE_system0(data, threadData);

  
  TRACE_POP
  return 0;
}

#ifdef FMU_EXPERIMENTAL
#endif
/* forward the main in the simulation runtime */
extern int _main_SimulationRuntime(int argc, char**argv, DATA *data, threadData_t *threadData);

#include "PowerSystem_12jac.h"
#include "PowerSystem_13opt.h"

struct OpenModelicaGeneratedFunctionCallbacks PowerSystem_callback = {
   NULL,
   NULL,
   NULL,
   PowerSystem_callExternalObjectConstructors,
   PowerSystem_callExternalObjectDestructors,
   NULL,
   NULL,
   NULL,
   #if !defined(OMC_NO_STATESELECTION)
   PowerSystem_initializeStateSets,
   #else
   NULL,
   #endif
   PowerSystem_initializeDAEmodeData,
   PowerSystem_functionODE,
   PowerSystem_functionAlgebraics,
   PowerSystem_functionDAE,
   PowerSystem_functionLocalKnownVars,
   PowerSystem_input_function,
   PowerSystem_input_function_init,
   PowerSystem_input_function_updateStartValues,
   PowerSystem_output_function,
   PowerSystem_function_storeDelayed,
   PowerSystem_updateBoundVariableAttributes,
   0 /* useHomotopy */,
   PowerSystem_functionInitialEquations,
   PowerSystem_functionInitialEquations_lambda0,
   PowerSystem_functionRemovedInitialEquations,
   PowerSystem_updateBoundParameters,
   PowerSystem_checkForAsserts,
   PowerSystem_function_ZeroCrossingsEquations,
   PowerSystem_function_ZeroCrossings,
   PowerSystem_function_updateRelations,
   PowerSystem_checkForDiscreteChanges,
   PowerSystem_zeroCrossingDescription,
   PowerSystem_relationDescription,
   PowerSystem_function_initSample,
   PowerSystem_INDEX_JAC_A,
   PowerSystem_INDEX_JAC_B,
   PowerSystem_INDEX_JAC_C,
   PowerSystem_INDEX_JAC_D,
   PowerSystem_initialAnalyticJacobianA,
   PowerSystem_initialAnalyticJacobianB,
   PowerSystem_initialAnalyticJacobianC,
   PowerSystem_initialAnalyticJacobianD,
   PowerSystem_functionJacA_column,
   PowerSystem_functionJacB_column,
   PowerSystem_functionJacC_column,
   PowerSystem_functionJacD_column,
   PowerSystem_linear_model_frame,
   PowerSystem_linear_model_datarecovery_frame,
   PowerSystem_mayer,
   PowerSystem_lagrange,
   PowerSystem_pickUpBoundsForInputsInOptimization,
   PowerSystem_setInputData,
   PowerSystem_getTimeGrid,
   PowerSystem_symEulerUpdate,
   PowerSystem_function_initSynchronous,
   PowerSystem_function_updateSynchronous,
   PowerSystem_function_equationsSynchronous,
   PowerSystem_read_input_fmu
   #ifdef FMU_EXPERIMENTAL
   ,PowerSystem_functionODE_Partial
   ,PowerSystem_functionFMIJacobian
   #endif
   ,PowerSystem_inputNames


};

void PowerSystem_setupDataStruc(DATA *data, threadData_t *threadData)
{
  assertStreamPrint(threadData,0!=data, "Error while initialize Data");
  data->callback = &PowerSystem_callback;
  data->modelData->modelName = "PowerSystem";
  data->modelData->modelFilePrefix = "PowerSystem";
  data->modelData->resultFileName = NULL;
  data->modelData->modelDir = "C:/Users/Joachim/Documents/Research/HybridCosimulation/ModelicaModels";
  data->modelData->modelGUID = "{c6327117-e5f2-4e48-abcd-318439d1e7c4}";
  data->modelData->initXMLData = NULL;
  data->modelData->modelDataXml.infoXMLData =
  #if defined(OMC_MINIMAL_METADATA)
    NULL;
  #else
  #include "PowerSystem_info.c"
  #endif
  ;
  
  data->modelData->nStates = 3;
  data->modelData->nVariablesReal = 10;
  data->modelData->nDiscreteReal = 0;
  data->modelData->nVariablesInteger = 0;
  data->modelData->nVariablesBoolean = 0;
  data->modelData->nVariablesString = 0;
  data->modelData->nParametersReal = 6;
  data->modelData->nParametersInteger = 0;
  data->modelData->nParametersBoolean = 0;
  data->modelData->nParametersString = 0;
  data->modelData->nInputVars = 3;
  data->modelData->nOutputVars = 3;
  
  data->modelData->nAliasReal = 0;
  data->modelData->nAliasInteger = 0;
  data->modelData->nAliasBoolean = 0;
  data->modelData->nAliasString = 0;
  
  data->modelData->nZeroCrossings = 2;
  data->modelData->nSamples = 0;
  data->modelData->nRelations = 2;
  data->modelData->nMathEvents = 0;
  data->modelData->nExtObjs = 0;
  data->modelData->modelDataXml.fileName = "PowerSystem_info.json";
  data->modelData->modelDataXml.modelInfoXmlLength = 0;
  data->modelData->modelDataXml.nFunctions = 0;
  data->modelData->modelDataXml.nProfileBlocks = 0;
  data->modelData->modelDataXml.nEquations = 12;
  data->modelData->nMixedSystems = 0;
  data->modelData->nLinearSystems = 0;
  data->modelData->nNonLinearSystems = 0;
  data->modelData->nStateSets = 0;
  data->modelData->nJacobians = 4;
  data->modelData->nOptimizeConstraints = 0;
  data->modelData->nOptimizeFinalConstraints = 0;
  
  data->modelData->nDelayExpressions = 0;
  
  data->modelData->nClocks = 0;
  data->modelData->nSubClocks = 0;
  
  data->modelData->nSensitivityVars = 0;
  data->modelData->nSensitivityParamVars = 0;
}

#ifdef __cplusplus
}
#endif

static int rml_execution_failed()
{
  fflush(NULL);
  fprintf(stderr, "Execution failed!\n");
  fflush(NULL);
  return 1;
}

