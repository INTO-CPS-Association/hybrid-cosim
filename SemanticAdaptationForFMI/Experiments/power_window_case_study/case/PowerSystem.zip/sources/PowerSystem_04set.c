/* Initial State Set */
#include "PowerSystem_model.h"
#include "PowerSystem_11mix.h"
#include "PowerSystem_12jac.h"
#if defined(__cplusplus)
extern "C" {
#endif
/* funtion initialize state sets */
void PowerSystem_initializeStateSets(int nStateSets, STATE_SET_DATA* statesetData, DATA *data)
{
}

#if defined(__cplusplus)
}
#endif

