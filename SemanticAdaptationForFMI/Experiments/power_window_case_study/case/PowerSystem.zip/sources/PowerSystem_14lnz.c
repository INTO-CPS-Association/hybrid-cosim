/* Linearization */
#include "PowerSystem_model.h"
#if defined(__cplusplus)
extern "C" {
#endif

const char *PowerSystem_linear_model_frame()
{
  return "model linear_PowerSystem\n  parameter Integer n = 3; // states\n  parameter Integer k = 3; // top-level inputs\n  parameter Integer l = 3; // top-level outputs\n"
  "  parameter Real x0[3] = {%s};\n"
  "  parameter Real u0[3] = {%s};\n"
  "  parameter Real A[3,3] = [%s];\n"
  "  parameter Real B[3,3] = [%s];\n"
  "  parameter Real C[3,3] = [%s];\n"
  "  parameter Real D[3,3] = [%s];\n"
  "  Real x[3](start=x0);\n"
  "  input Real u[3](start= u0);\n"
  "  output Real y[3];\n"
  "\n    Real 'x_i' = x[1];\n  Real 'x_omega' = x[2];\n  Real 'x_theta' = x[3];\n  Real 'u_d' = u[1];\n  Real 'u_tau' = u[2];\n  Real 'u_u' = u[3];\n  Real 'y_i' = y[1];\n  Real 'y_omega' = y[2];\n  Real 'y_theta' = y[3];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\nend linear_PowerSystem;\n";
}
const char *PowerSystem_linear_model_datarecovery_frame()
{
  return "model linear_PowerSystem\n  parameter Integer n = 3; // states\n  parameter Integer k = 3; // top-level inputs\n  parameter Integer l = 3; // top-level outputs\n  parameter Integer nz = 4; // data recovery variables\n"
  "  parameter Real x0[3] = {%s};\n"
  "  parameter Real u0[3] = {%s};\n"
  "  parameter Real z0[4] = {%s};\n"
  "  parameter Real A[3,3] = [%s];\n"
  "  parameter Real B[3,3] = [%s];\n"
  "  parameter Real C[3,3] = [%s];\n"
  "  parameter Real D[3,3] = [%s];\n"
  "  parameter Real Cz[4,3] = [%s];\n"
  "  parameter Real Dz[4,3] = [%s];\n"
  "  Real x[3](start=x0);\n"
  "  input Real u[3](start= u0);\n"
  "  output Real y[3];\n"
  "  output Real z[4];\n"
  "\n  Real 'x_i' = x[1];\n  Real 'x_omega' = x[2];\n  Real 'x_theta' = x[3];\n  Real 'u_d' = u[1];\n  Real 'u_tau' = u[2];\n  Real 'u_u' = u[3];\n  Real 'y_i' = y[1];\n  Real 'y_omega' = y[2];\n  Real 'y_theta' = y[3];\n  Real 'z_V' = z[1];\n  Real 'z_d' = z[2];\n  Real 'z_tau' = z[3];\n  Real 'z_u' = z[4];\n\n"
  "equation\n  der(x) = A * x + B * u;\n  y = C * x + D * u;\n  z = Cz * x + Dz * u;\nend linear_PowerSystem;\n";
}
#if defined(__cplusplus)
}
#endif

